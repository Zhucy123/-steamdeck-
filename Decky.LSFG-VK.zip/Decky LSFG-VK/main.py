"""
Main entry point for the lsfg-vk Decky Loader plugin.

This file imports and exposes the Plugin class from the lsfg_vk package.
"""

from lsfg_vk import Plugin

__all__ = ['Plugin']
